#include<iostream>
using namespace std;

void cd(){
	cout<<"cd...."<<endl;
	cout<<"Open floder."<<endl;
}
