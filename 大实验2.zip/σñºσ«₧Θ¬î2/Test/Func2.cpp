#include<iostream>
using namespace std;

void cat(){
	cout<<"cat...."<<endl;
	cout<<"Concatenate files and print on the standard output. "<<endl;

}
