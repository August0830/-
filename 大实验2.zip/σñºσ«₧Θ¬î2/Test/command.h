
void copy();
void cd();
void cat();
