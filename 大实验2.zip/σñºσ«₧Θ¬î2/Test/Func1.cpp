#include<iostream>
using namespace std;

void copy(){
	cout<<"copy...."<<endl;
	cout<<"Copy files and directories, Copy SOURCE to DEST, or multiple SOURCE(s) to DIRECTORY. "<<endl;
}
