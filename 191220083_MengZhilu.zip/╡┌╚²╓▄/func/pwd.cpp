#include <iostream>
#include <string.h>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
using namespace std;
void pwd();
int main(int argc,char* argv[])
{
	pwd();
}
void pwd()
{
        char path[100]={};
        //cout<<"pwd: ";
        getcwd(path,100);
        cout<<"pwd: "<<path<<endl;
}

