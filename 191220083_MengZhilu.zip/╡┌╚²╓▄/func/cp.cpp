#include <iostream>
using namespace std;
#include <fstream>
#include <string>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
bool cp(const char *filename1,const char *filename2);
bool cpr(string pthsrc,string pthdst);
int main(int argc, char *argv[])
{
        string mode=argv[0];//cout<<mode<<endl;
	char *file1,*file2;
	/*cin>>mode;
	char file1[100]={};
	char file2[100]={};
	cin>>file1>>file2;
	if(mode=="-r")
		cpr(file1,file2);
	else if(mode=="#")
		cp(file1,file2);*/
	for(int i=1;i<argc;++i)
	{
		file1=strtok(argv[i]," ");
                file2=strtok(NULL," ");
	//	cout<<"capture test "<<file1<<" "<<file2<<endl;
                while(file1!=NULL && file2!=NULL)
                {
                        if(mode=="-r")
				cpr(file1,file2);
			else if(mode=="#")
				cp(file1,file2);
                        file1=strtok(NULL," ");
                        file2=strtok(NULL," ");
                }

	}
}
bool cp(const char *filename1,const char*filename2){
	ifstream read;
	read.open(filename1,ios_base::in);
	if(read==NULL){
		cout<<"cp: 无法获取'"<<filename1<<"'的文件状态(stat)：没有那个文件或目录"<<endl;
	return false;}
	string file1;
	ofstream write;
	write.open(filename2,ios_base::out);
	if(write==NULL){
		cout<<"打开文件失败"<<endl;
		return false;}
	while(!read.eof()){
		getline(read,file1);
		write<<file1<<endl;}
	read.close();
	write.close();
	return true;
} 
bool cpr(string pthsrc, string pthdst)
{
	DIR *dp;
	dp=opendir(pthsrc.c_str());
	if(dp==NULL)
	{
                 cout<<"无法获取‘"<<pthsrc<<"’的文件状态(stat):没有那个文件";
                return false;
	}
        struct dirent* entry;
        entry=readdir(dp);
	//cout<<entry->d_name<<endl;
	//cout<<pthdst<<endl;
        mode_t mode=umask(0);
        mkdir(pthdst.c_str(),0777);
        umask(mode);
	if(entry==NULL) cout<<"no file open";
        while(entry!=NULL)
	{
       		string nds=pthdst+"/"+entry->d_name;
		string nsrc=pthsrc+"/"+entry->d_name;
                if(strcmp(entry->d_name,".")!=0 && strcmp(entry->d_name,"..")!=0)
		{
			if(entry->d_type==DT_DIR)
			{
				//cout<<pthdst<<endl;
				mode_t mode=umask(0);
                        	mkdir(nds.c_str(),0777);
				umask(mode);
				//cout<<nsrc<<endl<<nds<<endl;
                        	cpr(nsrc.c_str(), nds.c_str());
			}
			else
			{
				//cout<<nsrc<<endl<<nds<<endl;
                        	cp(nsrc.c_str(), nds.c_str());
			}
		}
        	entry=readdir(dp);
	}
	closedir(dp);
	return true;
}
