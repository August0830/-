#include <iostream>
#include <string.h>
#include <cstring>
#include <fstream>
using namespace std;
bool wc(int &byte, int &word, int &line,char *file);
int main(int argc, char *argv[])
{
	string mode=argv[0];
//	cout<<"mode "<<mode<<endl;
	char *file;
	int byte=0,word=0,line=0;
	for(int i=1;i<argc;++i)
        {
                file=strtok(argv[i]," ");
                while(file!=NULL)
                {
			wc(byte,word,line,file);
			if(mode=="#")
				cout<<line<<" "<<word<<" "<<byte<<" "<<file<<endl;
			else if(mode=="-l")
				cout<<line<<" "<<file<<endl;
			else if(mode=="-w")
				cout<<word<<" "<<file<<endl; 
			else if(mode=="-c")
				cout<<byte<<" "<<file<<endl;
			file=strtok(NULL," ");   
                }

        }


}
bool wc(int &byte, int &word, int &line,char *file)
{
	ifstream read;
	byte=0,word=0,line=0;//prepare
	read.open(file);
	if(read==NULL)
	{
		cout<<file<<" 没有那个文件或目录"<<endl;
		return false;
	}
	string stmp;
	read>>stmp;
	while(!read.eof())
	{
		read>>stmp;
		word++;
	}
	read.clear();read.seekg(0, ios::beg);
	getline(read,stmp);
	while(!read.eof())
	{
		line++;
		byte+=stmp.size()+1;
		getline(read,stmp);
	}
	read.close();
	return true;
}
