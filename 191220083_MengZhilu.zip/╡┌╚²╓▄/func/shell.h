#include <iostream>
#include <limits.h>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <sstream>
#include <stdlib.h>
#include <fstream>
using namespace std;
class Command
{
        public:
        string cmd,mode;
        vector<string> obj;
	vector<string> cmdlist;
        virtual void spcfic(){};
        void AnaCmd(string &cmd, string &mode, vector<string> &obj,vector<string> cmdlist);
        bool correction(string &cmd, vector<string> cmdlist);
	bool inicmdlist(vector<string> &cmdlist);
};
extern char oridir[100];

bool Command::correction(string &cmd, vector<string> cmdlist)
{
        int smlar=0,j=0,max=0;
        string stdc,trgc,target,judge;
        trgc=cmd;
        for(int k=0;k<cmdlist.size();++k)
        {
                stdc=cmdlist[k];smlar=0;j=0;
                for(int i=0;i<trgc.size() && j<stdc.size();++i)
                {
                        if(trgc[i]==stdc[j])
                        {
                                smlar++;
                                j++;
                        }
                }
                if(smlar>max)
                {
                        max=smlar;
                        target=stdc;
                }
        }
        cout<<"请问是否希望输入 "<<target<<" 若是请输入Y或y 不是请输入任意其他键"<<endl;
        cin>>judge;
        if(judge=="Y" || judge=="y")
        {
                cmd=target;
                return true;
        }
        else
        {
        //      cout<<"no change "<<cmd<<endl;
                return false;
        }
}

void Command::AnaCmd(string &cmd, string &mode, vector<string> &obj,vector<string> cmdlist)
{
        istringstream is(cmd);string stmp,tmpcmd;
        bool judge=false;
        is>>tmpcmd;
        while(is>>stmp)
        {
                if(stmp.find("-")!=string::npos)
                        mode=stmp;
                else
                {
                        char filepath[100]={};
                        memset(filepath,0,sizeof(filepath));
                        realpath(stmp.c_str(),filepath)!=NULL;
                        stmp=filepath;//cout<<"realpath "<<stmp<<endl;
                        obj.push_back(stmp);
                }
                //cout<<stmp<<endl;
        }
        for(int i=0;i<cmdlist.size();++i)
        {
                if(cmdlist[i]==tmpcmd)
                        judge=true;
        }
        while(judge==false)
        {
                if(judge==false)
                {
                        if(correction(tmpcmd, cmdlist)==false)
                        {
                                cout<<"请输入新命令："<<endl;
                                string newcmd;
                                getline(cin,newcmd);getline(cin,newcmd);
                                istringstream tis(newcmd);
                                tis>>tmpcmd;
                                for(int i=0;i<cmdlist.size();++i)
                                {
                                        if(cmdlist[i]==tmpcmd)
                                                judge=true;
                                }

                        }
                        else
                                judge=true;
                }
        }//cout<<tmpcmd<<endl;
        cmd=tmpcmd;//cout<<cmd<<endl;
}
bool Command::inicmdlist(vector<string> &cmdlist)
{
        ifstream read;string stmp;
        read.open("./cmdlist.txt",ios_base::in);//之后的路径要基于系统初次获取的安装路径
        if(read==NULL)
        {
                cout<<"无法打开命令列表"<<endl;
                return false;
        }
        while(!read.eof())
        {
                read>>stmp;
                cmdlist.push_back(stmp);
        }
        read.close();
        return true;
}

