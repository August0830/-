#include <iostream>
#include<fstream>
#include <string>
#include <cstring>
#include "shell.h"
using namespace std;
bool man(string com);
int main(int argc, char *argv[])
{
	char *file;
        for(int i=1;i<argc;++i)
        {
		
                file=strtok(argv[i]," ");
		string com=file;
                //cout<<"cd "<<file<<endl;
                while(file!=NULL)
                {       man(com);
                        file=strtok(NULL," ");
                }
        }

}
bool man(string com)
{
	
	com=com+".txt";cout<<com<<endl;
	ifstream read;string stmp;
	read.open(com.c_str(), ios_base::in);
	if(read==NULL)
	{
		cout<<"没有该命令的条目手册"<<endl;
		return false;
	}
	while(!read.eof())
	{
		getline(read,stmp);
		cout<<stmp<<endl;	
	}
	read.close();
	return true;
}
