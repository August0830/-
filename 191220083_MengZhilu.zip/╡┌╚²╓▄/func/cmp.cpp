#include <iostream>
#include <string.h>
#include <cstring>
using namespace std;
#include <fstream>
#define _GLIBCXX_USE_CXX11_ABI 0
int Locate(string str1,string str2);
bool cmp(char *file1, char *file2);
int main(int argc, char *argv[])
{
	char *file1,*file2;
	for(int i=1;i<argc;++i)
	{
		file1=strtok(argv[i]," ");
		file2=strtok(NULL," ");
		while(file1!=NULL && file2!=NULL)
		{
			cmp(file1,file2);
			file1=strtok(NULL," ");
			file2=strtok(NULL," ");
		}
	}
	if(file1!=NULL || file2!=NULL)
                        cout<<"输入参数不匹配！"<<endl;	

}
int Locate(string str1,string str2){
	int max=(str1.size()>=str2.size() ? str1.size():str2.size());
	if(str1.empty()||str2.empty())
		return 0;
	for(int i=0;i<max;++i){
		if(str1[i]!=str2[i])
			return i;}
	if(str1.size()==str2.size())
		return -1;//完全相等
	else return max+1;}
bool cmp(char *file1, char *file2)
{
	ifstream read1,read2;
	read1.open(file1, ios_base::in);
	read2.open(file2, ios_base::in);
	if(read1==NULL && read2==NULL){
		cout<<file1<<":没有那个文件或目录"<<endl;
		return false;}
	if(read2==NULL){
		cout<<file2<<":没有那个文件或目录"<<endl;
		return false;}
	if(read1==NULL){
		cout<<file1<<":没有那个文件或目录"<<endl;
		return false;}
	int line=0,byte=0;
	string str1,str2;
	getline(read1,str1);
	getline(read2,str2);
	while(!read1.eof() && !read2.eof()){
		int unit;
		if(!str1.empty())
			unit=sizeof(str1[0]);
		else
			unit=sizeof(str2[0]);
		int loc=Locate(str1,str2);
		if(loc==-1){
			line++;
			byte+=unit*str1.size();}
		else{
			byte+=unit*(loc+1);
			cout<<file1<<" "<<file2<<" 不同：";
			cout<<"第"<<byte<<"字节 第"<<line+1<<"行"<<endl;
			break;}
		getline(read1,str1);
		getline(read2,str2);
}
	read1.close();read2.close();
	return true;
}


