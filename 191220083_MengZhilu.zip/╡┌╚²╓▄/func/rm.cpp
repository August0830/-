#include <iostream>
#include <string.h>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
using namespace std;
void rm(char *path);
int main(int argc, char *argv[])
{
	char *file;
        for(int i=1;i<argc;++i)
        {
                file=strtok(argv[i]," ");
                //cout<<"cd "<<file<<endl;
                while(file!=NULL)
                {       rm(file);
                        file=strtok(NULL," ");
                }
        }

}
void rm(char *path)//需要说明的是 本地目录可以直接输入 但是上一级的需要绝对路径
{
        int jug;
        jug=remove(path);
        if(jug!=0)
                cout<<"rm: 无法删除'"<<path<<"': 没有那个文件或目录"<<endl;
}
