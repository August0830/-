#include <iostream>
#include <string.h>
#include <cstring>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
using namespace std;
void mv(char *oldpath, char *newpath);
int main(int argc, char *argv[])
{
	char *file1,*file2;
        for(int i=1;i<argc;++i)
        {
                file1=strtok(argv[i]," ");
                file2=strtok(NULL," ");
                while(file1!=NULL && file2!=NULL)
                {
                        mv(file1,file2);
                        file1=strtok(NULL," ");
                        file2=strtok(NULL," ");
                }
        }
        if(file1!=NULL || file2!=NULL)
                        cout<<"输入参数不匹配！"<<endl;
}
void mv(char *oldpath, char *newpath)
{
        if(rename(oldpath,newpath)!=0)//hello-hello1 /home/file /home/file2 改>名 hello /home/newfile/hello 移动文件
                cout<<"无法修改！"<<endl;//"mv: 无法获取'"<<oldpath<<"' 的文件状态(stat): 没有那个文件或目录";
}

