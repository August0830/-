#include <iostream>
#include<sys/wait.h>
#include<stdlib.h>
#include <string>
#include "shell.h"
#include <cstring>
#include <string.h>
#include <sys/types.h>
#include <pwd.h>
#include <stdio.h>
#include <unistd.h>
#include <sstream>
#define Green "\e[1;32m"
#define Blue "\e[1;34m"
#define White "\e[0m"
using namespace std;
void printuser();
void cd(string path);
char oridir[100];
int main()
{
	Command Cmd;
        Cmd.mode="#";
	getcwd(oridir,100);//cout<<oridir<<endl;
//	char *orival=getenv("PATH");cout<<orival<<endl;
	Cmd.inicmdlist(Cmd.cmdlist);
	printuser();
        getline(cin,Cmd.cmd);
	Cmd.AnaCmd(Cmd.cmd,Cmd.mode,Cmd.obj,Cmd.cmdlist);
	string stmp,list;
	pid_t pid;
	int status;
	while(Cmd.cmd!="exit")
	{
		for(int i=0;i<Cmd.obj.size();++i)
		{
			if(list.empty()==true)
				list=Cmd.obj[i];
			else
				list=list+" "+Cmd.obj[i];
			//strcat(list.c_str(),stmp.c_str());
		//	strcat(list.c_str(),stmp.c_str());
		}
		//cout<<"hecheng "<<list<<endl;
		if(Cmd.cmd=="cd")
			cd(list);
		else
		{
			pid=fork();
			if(pid<0)
				perror("fork error");
			else if(pid==0)
			{
				execl(Cmd.cmd.c_str(),Cmd.mode.c_str(),list.c_str(),NULL);
				perror("execlp error");  //如果execlp()函数无法执行，则输出错误信息！
	    			exit(127);

			}
			if((pid = waitpid(pid,&status,0)) < 0)//父进程等待子进程结束
			 	perror("waitpid error");
		}
			printuser();
			list.clear();Cmd.obj.clear();Cmd.cmd.clear();
			//setenv("PATH",orival,1);
			//char *val=getenv("PATH");cout<<"now val "<<val<<endl;//initialize
        		getline(cin,Cmd.cmd);//getline(cin,Cmd.cmd);
			Cmd.AnaCmd(Cmd.cmd,Cmd.mode,Cmd.obj,Cmd.cmdlist);
		//Cmd.obj.clear();
	}

	return 0;
}
void printuser()
{
	char host[100]={};
	gethostname(host,100);
	uid_t uid;
	uid = getuid();
	char path[100]={};
        getcwd(path,100);
	printf(Green "%s@%d: ",host,uid);
	printf(Blue "%s",path);
	printf(White"$ ");
	//cout<<"else";
}
void cd(string path)
{
        //cout<<"cd "<<path<<endl;
	//char curpath[100]={};
	//getcwd(curpath,100);
       // char* val;
       // val=getenv("PATH");cout<<"prev val "<<val<<endl;
        if(chdir(path.c_str())!=0)
                cout<<"cd"<<path<<": 没有那个文件或目录"<<endl;
       // getcwd(curpath,100);cout<<"curpath: "<<curpath<<endl;
	//const char *cur=curpath;
        //setenv("PATH",cur,1);
	//val =getenv("PATH");cout<<"cur val "<<val<<endl;
       // cout<<"pwd: "<<curpath<<endl;
}
/*void Command::AnaCmd(string &cmd, string &mode, vector<string> &obj)
{
        istringstream is(cmd);string stmp,tmpcmd;
        is>>tmpcmd;
        while(is>>stmp)
        {
                if(stmp.find("-")!=string::npos)
                        mode=stmp;
                else
                {
                        char filepath[100]={};
                        memset(filepath,0,sizeof(filepath));
                        realpath(stmp.c_str(),filepath)!=NULL;
                        stmp=filepath;//cout<<"realpath "<<stmp<<endl;
                        obj.push_back(stmp);
                }
                //cout<<stmp<<endl;
        }
        cmd=tmpcmd;
}*/

