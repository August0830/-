#include <iostream>
using namespace std;
#include <fstream>
#include <string.h>
#include <cstring>
bool cat(char *filename);
int main(int argc, char* argv[])
{
	char *file;
        for(int i=1;i<argc;++i)
        {
                file=strtok(argv[i]," ");
                //cout<<"cd "<<file<<endl;
                while(file!=NULL)
                {       cat(file);
                        file=strtok(NULL," ");
                }
        }

//	return 0;
}
bool cat(char *filename){
	
	ifstream read;
	read.open(filename, ios_base::in);
	if(read==NULL){
		cout<<filename<<":没有那个文件或目录"<<endl;
		return false;}
	string stmp;
	while(!read.eof()){
		getline(read,stmp);
		cout<<stmp<<endl;}
	read.close();
	return true;}
